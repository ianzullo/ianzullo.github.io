import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * The player.
 * 
 * @ian zullo
 * @beta 1.0.1
 */
public class Raptor extends Animal
{
    /**
     * Act - do whatever the Raptor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    private int kills = 0;
    
    public void act() 
    {
       checkKeys();
       
       if (canSee(Dino.class))
        {
            eat(Dino.class);
            kills++;
            }
              
        if (kills == 39) {
           Greenfoot.setWorld(new WinScreen());
        }
        }
        
    public void checkKeys()
    {
        if ( Greenfoot.isKeyDown("A") )
        {
            turn(-6);
        }
        if ( Greenfoot.isKeyDown("D") )
        {
            turn(6);
        }
        if ( Greenfoot.isKeyDown("W") )
        {
            move(5);
      if ( Greenfoot.isKeyDown("shift") )
        {
            move(3);
            }
       }
        
        if ( Greenfoot.isKeyDown("S") )
        {
            move(-3);
        }
        
        if ( Greenfoot.isKeyDown("left") )
        {
            turn(-6);
        }
        if ( Greenfoot.isKeyDown("right") )
        {
            turn(6);
        }
        if ( Greenfoot.isKeyDown("up") )
        {
            move(5);
                  if ( Greenfoot.isKeyDown("shift") )
        {
            move(3);
            }
        }
        if ( Greenfoot.isKeyDown("down") )
        {
            move(-3);
        }
    }
}
