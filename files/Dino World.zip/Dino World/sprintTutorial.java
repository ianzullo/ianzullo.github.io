import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Teaches the player how to sprint.
 * 
 * @ian zullo
 * @beta 1.0.1
 */
public class sprintTutorial extends Actor
{
    public int removal = 0;
    public void act() 
    {
        removal++;
        if (Greenfoot.isKeyDown("shift"))
        setImage("good-job.png");
        if(removal >= 200)
        getWorld().removeObject(this);
    }    
}
