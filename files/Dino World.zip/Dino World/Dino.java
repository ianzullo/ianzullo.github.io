import greenfoot.*; 

public class Dino extends Animal
{
    public void act()
    {
        move(4);
        
        if ( Greenfoot.getRandomNumber(100) < 10 )
        {
            turn( Greenfoot.getRandomNumber(40)-20 );
        }
        
        if (atWorldEdge())
        {
            turn(7);
        }
        
        if (canSee(raptorBaby.class))
        {
            eat(raptorBaby.class);
        }
    }
}
