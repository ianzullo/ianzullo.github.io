import greenfoot.*; 

/**
 * The real world.
 * 
 * @ian zullo 
 * @beta 1.0.3
 */
public class DinoWorld extends World
{
    public DinoWorld() 
    {
        super(800, 400, 1);
        prepare();
    }
    
    private void prepare()
    {

        raptorBaby raptorbaby = new raptorBaby();
        addObject(raptorbaby,50,212);
        raptorBaby raptorbaby2 = new raptorBaby();
        addObject(raptorbaby2,50,212);
        raptorBaby raptorbaby3 = new raptorBaby();
        addObject(raptorbaby3,50,212);
        raptorBaby raptorbaby4 = new raptorBaby();
        addObject(raptorbaby4,50,212);
        raptorBaby raptorbaby5 = new raptorBaby();
        addObject(raptorbaby5,122,217);
        raptorBaby raptorbaby6 = new raptorBaby();
        addObject(raptorbaby6,122,217);
        raptorBaby raptorbaby7 = new raptorBaby();
        addObject(raptorbaby7,122,217);
        raptorBaby raptorbaby8 = new raptorBaby();
        addObject(raptorbaby8,122,217);
        raptorBaby raptorbaby9 = new raptorBaby();
        addObject(raptorbaby9,122,217);
        raptorBaby raptorbaby10 = new raptorBaby();
        addObject(raptorbaby10,195,242);
        raptorBaby raptorbaby11 = new raptorBaby();
        addObject(raptorbaby11,195,242);
        raptorBaby raptorbaby12 = new raptorBaby();
        addObject(raptorbaby12,195,242);
        raptorBaby raptorbaby13 = new raptorBaby();
        addObject(raptorbaby13,195,242);
        raptorBaby raptorbaby14 = new raptorBaby();
        addObject(raptorbaby14,251,284);
        raptorBaby raptorbaby15 = new raptorBaby();
        addObject(raptorbaby15,251,284);
        raptorBaby raptorbaby16 = new raptorBaby();
        addObject(raptorbaby16,251,284);
        raptorBaby raptorbaby17 = new raptorBaby();
        addObject(raptorbaby17,251,284);
        raptorBaby raptorbaby18 = new raptorBaby();
        addObject(raptorbaby18,194,175);
        raptorBaby raptorbaby19 = new raptorBaby();
        addObject(raptorbaby19,194,175);
        raptorBaby raptorbaby20 = new raptorBaby();
        addObject(raptorbaby20,194,175);
        raptorBaby raptorbaby21 = new raptorBaby();
        addObject(raptorbaby21,194,175);
        raptorBaby raptorbaby22 = new raptorBaby();
        addObject(raptorbaby22,194,175);
        raptorBaby raptorbaby23 = new raptorBaby();
        addObject(raptorbaby23,265,142);
        raptorBaby raptorbaby24 = new raptorBaby();
        addObject(raptorbaby24,265,142);
        raptorBaby raptorbaby25 = new raptorBaby();
        addObject(raptorbaby25,265,142);
        raptorBaby raptorbaby26 = new raptorBaby();
        addObject(raptorbaby26,265,142);
        Raptor raptor = new Raptor();
        addObject(raptor,283,215);
        Dino dino = new Dino();
        addObject(dino,562,43);
        Dino dino2 = new Dino();
        addObject(dino2,562,43);
        Dino dino3 = new Dino();
        addObject(dino3,646,87);
        Dino dino4 = new Dino();
        addObject(dino4,646,87);
        Dino dino5 = new Dino();
        addObject(dino5,725,42);
        Dino dino6 = new Dino();
        addObject(dino6,725,42);
        Dino dino7 = new Dino();
        addObject(dino7,725,174);
        Dino dino8 = new Dino();
        addObject(dino8,725,174);
        Dino dino9 = new Dino();
        addObject(dino9,574,101);
        Dino dino10 = new Dino();
        addObject(dino10,574,101);
        Dino dino11 = new Dino();
        addObject(dino11,625,153);
        Dino dino12 = new Dino();
        addObject(dino12,625,153);
        Dino dino13 = new Dino();
        addObject(dino13,733,117);
        Dino dino14 = new Dino();
        addObject(dino14,733,117);
        Dino dino15 = new Dino();
        addObject(dino15,553,191);
        Dino dino16 = new Dino();
        addObject(dino16,553,191);
        Dino dino17 = new Dino();
        addObject(dino17,625,233);
        Dino dino18 = new Dino();
        addObject(dino18,625,233);
        Dino dino19 = new Dino();
        addObject(dino19,703,259);
        Dino dino20 = new Dino();
        addObject(dino20,703,259);
        Dino dino21 = new Dino();
        addObject(dino21,550,327);
        Dino dino22 = new Dino();
        addObject(dino22,550,327);
        Dino dino23 = new Dino();
        addObject(dino23,669,360);
        Dino dino24 = new Dino();
        addObject(dino24,669,360);
        Dino dino25 = new Dino();
        addObject(dino25,758,328);
        Dino dino26 = new Dino();
        addObject(dino26,758,328);
        Dino dino27 = new Dino();
        addObject(dino27,635,313);
        Dino dino28 = new Dino();
        addObject(dino28,635,313);
        Dino dino29 = new Dino();
        addObject(dino29,544,265);
        Dino dino30 = new Dino();
        addObject(dino30,544,265);
        Dino dino31 = new Dino();
        addObject(dino31,674,29);
        Dino dino32 = new Dino();
        addObject(dino32,674,29);
        Dino dino33 = new Dino();
        addObject(dino33,683,175);
        Dino dino34 = new Dino();
        addObject(dino34,683,175);
        Dino dino35 = new Dino();
        addObject(dino35,683,175);
        removeObject(dino35);
        Dino dino36 = new Dino();
        addObject(dino36,771,229);
        Dino dino37 = new Dino();
        addObject(dino37,771,229);
        Dino dino38 = new Dino();
        addObject(dino38,765,388);
        Dino dino39 = new Dino();
        addObject(dino39,765,388);
        Dino dino40 = new Dino();
        addObject(dino40,484,227);
        Dino dino41 = new Dino();
        addObject(dino41,484,227);
        removeObject(dino40);
    }

    public void act()
    {
      if (getObjects(raptorBaby.class).isEmpty())
      Greenfoot.setWorld(new LoseScreen());
    }
}