import greenfoot.*;  // imports Actor, World, Greenfoot, GreenfootImage

public class DinoWorld extends World
{
    /**
     * Create the turtle world. Our world has a size 
     * of 560x460 cells, where every cell is just 1 pixel.
     */
    public DinoWorld() 
    {
        super(800, 400, 1);
        prepare();
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Raptor raptor = new Raptor();
        addObject(raptor,85,218);
        Dino dino = new Dino();
        addObject(dino,698,93);
        Dino dino2 = new Dino();
        addObject(dino2,698,93);
        Dino dino3 = new Dino();
        addObject(dino3,698,93);
        Dino dino4 = new Dino();
        addObject(dino4,698,93);
        Dino dino5 = new Dino();
        addObject(dino5,698,93);
        Dino dino6 = new Dino();
        addObject(dino6,698,93);
        Dino dino7 = new Dino();
        addObject(dino7,698,93);
        Dino dino8 = new Dino();
        addObject(dino8,698,93);
        Dino dino9 = new Dino();
        addObject(dino9,698,93);
        Dino dino10 = new Dino();
        addObject(dino10,698,93);
        Dino dino11 = new Dino();
        addObject(dino11,696,207);
        Dino dino12 = new Dino();
        addObject(dino12,696,207);
        Dino dino13 = new Dino();
        addObject(dino13,696,207);
        Dino dino14 = new Dino();
        addObject(dino14,696,207);
        Dino dino15 = new Dino();
        addObject(dino15,696,207);
        Dino dino16 = new Dino();
        addObject(dino16,696,207);
        Dino dino17 = new Dino();
        addObject(dino17,696,207);
        Dino dino18 = new Dino();
        addObject(dino18,696,207);
        Dino dino19 = new Dino();
        addObject(dino19,696,207);
        Dino dino20 = new Dino();
        addObject(dino20,696,207);
        Dino dino21 = new Dino();
        addObject(dino21,699,319);
        Dino dino22 = new Dino();
        addObject(dino22,699,319);
        Dino dino23 = new Dino();
        addObject(dino23,699,319);
        Dino dino24 = new Dino();
        addObject(dino24,699,319);
        Dino dino25 = new Dino();
        addObject(dino25,699,319);
        Dino dino26 = new Dino();
        addObject(dino26,699,319);
        Dino dino27 = new Dino();
        addObject(dino27,699,319);
        Dino dino28 = new Dino();
        addObject(dino28,699,319);
        Dino dino29 = new Dino();
        addObject(dino29,699,319);
        Dino dino30 = new Dino();
        addObject(dino30,699,319);
        Dino dino31 = new Dino();
        addObject(dino31,592,205);
        Dino dino32 = new Dino();
        addObject(dino32,592,205);
        Dino dino33 = new Dino();
        addObject(dino33,592,205);
        Dino dino34 = new Dino();
        addObject(dino34,592,205);
        Dino dino35 = new Dino();
        addObject(dino35,592,205);
        Dino dino36 = new Dino();
        addObject(dino36,592,205);
        Dino dino37 = new Dino();
        addObject(dino37,592,205);
        Dino dino38 = new Dino();
        addObject(dino38,592,205);
        Dino dino39 = new Dino();
        addObject(dino39,592,205);
        Dino dino40 = new Dino();
        addObject(dino40,592,205);
        Fruit fruit = new Fruit();
        addObject(fruit,104,75);
        Fruit fruit2 = new Fruit();
        addObject(fruit2,81,110);
        Fruit fruit3 = new Fruit();
        addObject(fruit3,24,191);
        Fruit fruit4 = new Fruit();
        addObject(fruit4,29,104);
        Fruit fruit5 = new Fruit();
        addObject(fruit5,43,26);
        Fruit fruit6 = new Fruit();
        addObject(fruit6,32,337);
        Fruit fruit7 = new Fruit();
        addObject(fruit7,112,386);
        Fruit fruit8 = new Fruit();
        addObject(fruit8,142,338);
        Fruit fruit9 = new Fruit();
        addObject(fruit9,69,277);
        Fruit fruit10 = new Fruit();
        addObject(fruit10,220,277);
        Fruit fruit11 = new Fruit();
        addObject(fruit11,194,214);
        Fruit fruit12 = new Fruit();
        addObject(fruit12,162,155);
        Fruit fruit13 = new Fruit();
        addObject(fruit13,198,135);
        Fruit fruit14 = new Fruit();
        addObject(fruit14,159,37);
        Fruit fruit15 = new Fruit();
        addObject(fruit15,187,86);
        Fruit fruit16 = new Fruit();
        addObject(fruit16,274,89);
        Fruit fruit17 = new Fruit();
        addObject(fruit17,251,210);
        Fruit fruit18 = new Fruit();
        addObject(fruit18,246,353);
        Fruit fruit19 = new Fruit();
        addObject(fruit19,198,344);
        Fruit fruit20 = new Fruit();
        addObject(fruit20,357,354);
        Fruit fruit21 = new Fruit();
        addObject(fruit21,345,268);
        Fruit fruit22 = new Fruit();
        addObject(fruit22,336,69);
        Fruit fruit23 = new Fruit();
        addObject(fruit23,259,36);
    }
    public void act()
    {
      if (getObjects(Fruit.class).isEmpty())
      Greenfoot.setWorld(new LoseScreen());
    }
}