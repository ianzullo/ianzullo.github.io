import greenfoot.*; 

/**
 * Screen that greets the player when they win the game.
 * 
 * @ian zullo 
 * @beta 1.0.3
 */
public class WinScreen extends World
{
    /**
     * Constructor for objects of class WinScreen.
     * 
     */
    public WinScreen()
    {    
        super(800, 400, 1); 
    }
    public void act()
    {
        if (Greenfoot.isKeyDown("space")) Greenfoot.setWorld(new DinoWorld());
    }
}
