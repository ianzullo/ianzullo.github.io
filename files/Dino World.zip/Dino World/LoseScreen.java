import greenfoot.*; 

/**
 * Screen that greets the player when they lose.
 * 
 * @ian zullo 
 * @beta 1.0.3
 */
public class LoseScreen extends World
{
    /**
     * Constructor for objects of class LoseScreen.
     * 
     */
    public LoseScreen()
    {    
        super(800, 400, 1); 
    }
    public void act()
    {
        if (Greenfoot.isKeyDown("space")) Greenfoot.setWorld(new DinoWorld());
    }
}
