import greenfoot.*; 

/**
 * Screen that greets the player when they (obviously) win in the tutorial world.
 * 
 * @ian zullo 
 * @beta 1.0.3
 */
public class WinScreenTutorial extends World
{
    public WinScreenTutorial()
    {    
        super(800, 400, 1); 
    }
    public void act()
    {
        if (Greenfoot.isKeyDown("space")) Greenfoot.setWorld(new DinoWorld());
    }
}
