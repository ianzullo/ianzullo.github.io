import greenfoot.*; 

/**
 * Screen that greets the player when they (somehow) lose in the tutorial world.
 * 
 * @ian zullo 
 * @beta 1.0.3
 */
public class LoseScreenTutorial extends World
{
    public LoseScreenTutorial()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 400, 1); 
    }
    public void act()
    {
        if (Greenfoot.isKeyDown("space")) Greenfoot.setWorld(new TutorialWorld());
    }
}
