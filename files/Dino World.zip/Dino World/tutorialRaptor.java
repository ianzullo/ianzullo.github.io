import greenfoot.*; 

/**
 * An ancient hologram created by light to imitate the raptor in the tutorial world.
 * 
 * @ian zullo 
 * @beta 1.0.3
 */
public class tutorialRaptor extends Animal
{
    private int kills = 0;
    
    public void act() 
    {
       checkKeys();
       
       if (canSee(Dino.class))
        {
            eat(Dino.class);
            kills++;
            }
              
        if (kills == 5) {
           Greenfoot.setWorld(new WinScreenTutorial());
        }
        }
        
    public void checkKeys()
    {
        if ( Greenfoot.isKeyDown("A") )
        {
            turn(-6);
        }
        if ( Greenfoot.isKeyDown("D") )
        {
            turn(6);
        }
        if ( Greenfoot.isKeyDown("W") )
        {
            move(5);
      if ( Greenfoot.isKeyDown("shift") )
        {
            move(3);
            }
       }
        
        if ( Greenfoot.isKeyDown("S") )
        {
            move(-3);
        }
        
        if ( Greenfoot.isKeyDown("left") )
        {
            turn(-6);
        }
        if ( Greenfoot.isKeyDown("right") )
        {
            turn(6);
        }
        if ( Greenfoot.isKeyDown("up") )
        {
            move(5);
                  if ( Greenfoot.isKeyDown("shift") )
        {
            move(3);
            }
        }
        if ( Greenfoot.isKeyDown("down") )
        {
            move(-3);
        }
    }
}
