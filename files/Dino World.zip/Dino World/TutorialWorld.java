import greenfoot.*; 

/**
 * The "fake" tutorial world, created by shifting shards of light.
 * 
 * @ian zullo 
 * @beta 1.0.3
 */
public class TutorialWorld extends World
{
    public TutorialWorld() 
    {
        super(800, 400, 1);
        prepare();
    }
    
    private void prepare()
    {

        raptorBaby raptorbaby = new raptorBaby();
        addObject(raptorbaby,50,212);
        raptorBaby raptorbaby2 = new raptorBaby();
        addObject(raptorbaby2,50,212);
        raptorBaby raptorbaby3 = new raptorBaby();
        addObject(raptorbaby3,50,212);
        raptorBaby raptorbaby4 = new raptorBaby();
        addObject(raptorbaby4,50,212);
        raptorBaby raptorbaby5 = new raptorBaby();
        addObject(raptorbaby5,122,217);
        raptorBaby raptorbaby6 = new raptorBaby();
        addObject(raptorbaby6,122,217);
        raptorBaby raptorbaby7 = new raptorBaby();
        addObject(raptorbaby7,122,217);
        raptorBaby raptorbaby8 = new raptorBaby();
        addObject(raptorbaby8,122,217);
        raptorBaby raptorbaby9 = new raptorBaby();
        addObject(raptorbaby9,122,217);
        raptorBaby raptorbaby10 = new raptorBaby();
        addObject(raptorbaby10,195,242);
        raptorBaby raptorbaby11 = new raptorBaby();
        addObject(raptorbaby11,195,242);
        raptorBaby raptorbaby12 = new raptorBaby();
        addObject(raptorbaby12,195,242);
        raptorBaby raptorbaby13 = new raptorBaby();
        addObject(raptorbaby13,195,242);
        raptorBaby raptorbaby14 = new raptorBaby();
        addObject(raptorbaby14,251,284);
        raptorBaby raptorbaby15 = new raptorBaby();
        addObject(raptorbaby15,251,284);
        raptorBaby raptorbaby16 = new raptorBaby();
        addObject(raptorbaby16,251,284);
        raptorBaby raptorbaby17 = new raptorBaby();
        addObject(raptorbaby17,251,284);
        raptorBaby raptorbaby18 = new raptorBaby();
        addObject(raptorbaby18,194,175);
        raptorBaby raptorbaby19 = new raptorBaby();
        addObject(raptorbaby19,194,175);
        raptorBaby raptorbaby20 = new raptorBaby();
        addObject(raptorbaby20,194,175);
        raptorBaby raptorbaby21 = new raptorBaby();
        addObject(raptorbaby21,194,175);
        raptorBaby raptorbaby22 = new raptorBaby();
        addObject(raptorbaby22,194,175);
        raptorBaby raptorbaby23 = new raptorBaby();
        addObject(raptorbaby23,265,142);
        raptorBaby raptorbaby24 = new raptorBaby();
        addObject(raptorbaby24,265,142);
        raptorBaby raptorbaby25 = new raptorBaby();
        addObject(raptorbaby25,265,142);
        raptorBaby raptorbaby26 = new raptorBaby();
        addObject(raptorbaby26,265,142);
        Raptor raptor = new Raptor();
        addObject(raptor,283,215);
        sprintTutorial sprinttutorial = new sprintTutorial();
        addObject(sprinttutorial,121,69);

        if (getObjects(sprintTutorial.class).isEmpty());
        addObject(raptorbaby,121,69);
        Dino dino = new Dino();
        addObject(dino,624,202);
        Dino dino2 = new Dino();
        addObject(dino2,680,144);
        Dino dino3 = new Dino();
        addObject(dino3,693,263);
        Dino dino4 = new Dino();
        addObject(dino4,757,95);
        Dino dino5 = new Dino();
        addObject(dino5,759,330);
        removeObject(raptor);
        tutorialRaptor tutorialraptor = new tutorialRaptor();
        addObject(tutorialraptor,297,215);
    }

    public void act()
    {
      if (getObjects(raptorBaby.class).isEmpty())
      Greenfoot.setWorld(new LoseScreenTutorial());
    }
}
