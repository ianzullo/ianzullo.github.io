import greenfoot.*; 
import greenfoot.*; 
 
/**
 * Screen that greets the player.
 * 
 * @ian zullo 
 * @beta 1.0.3
 */
public class TitleScreen extends World
{
    public TitleScreen()
    {    
        super(800, 400, 1); 
        Greenfoot.start();
    }
    public void act()
    {
        if (Greenfoot.isKeyDown("space")) Greenfoot.setWorld(new TutorialWorld());
    }
}
