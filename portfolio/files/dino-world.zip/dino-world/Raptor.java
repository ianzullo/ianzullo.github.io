import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Raptor here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Raptor extends Animal
{
    /**
     * Act - do whatever the Raptor wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
       checkKeys();
       
       if (canSee(Dino.class))
        {
            eat(Dino.class);
            Greenfoot.playSound("raptor.wav");
        }
    }
    
    public void checkKeys()
    {
        if ( Greenfoot.isKeyDown("A") )
        {
            turn(-6);
        }
        if ( Greenfoot.isKeyDown("D") )
        {
            turn(6);
        }
        if ( Greenfoot.isKeyDown("W") )
        {
            move(5);
      if ( Greenfoot.isKeyDown("Space") )
        {
            move(3);
            }
       }
        
        if ( Greenfoot.isKeyDown("S") )
        {
            move(-3);
        }
        
        if ( Greenfoot.isKeyDown("left") )
        {
            turn(-6);
        }
        if ( Greenfoot.isKeyDown("right") )
        {
            turn(6);
        }
        if ( Greenfoot.isKeyDown("up") )
        {
            move(5);
                  if ( Greenfoot.isKeyDown("Space") )
        {
            move(3);
            }
        }
        if ( Greenfoot.isKeyDown("down") )
        {
            move(-3);
        }
    }
}
